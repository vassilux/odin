:mod:`son` -- Tools for working with SON, an ordered mapping
============================================================

.. automodule:: bson.son
   :synopsis: Tools for working with SON, an ordered mapping
   :members:
