"""Old pure-Python property types

Eventually the property types here will be
moved to the parent package as simple modules,
when support for their features are integrated.
"""
