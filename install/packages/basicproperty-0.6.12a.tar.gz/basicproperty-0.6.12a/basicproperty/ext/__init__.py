"""extension-specific property classes
"""
